export default {
  content: ["./index.html", "./Dashboard.jsx"],
  theme: { extend: {} },
  plugins: [],
}
